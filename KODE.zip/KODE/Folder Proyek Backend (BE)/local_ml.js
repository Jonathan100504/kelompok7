// local_ml.js — OCR lokal fokus struk (Tesseract.js utama, Donut/TrOCR fallback)
// ESM module

import fs from "fs";
import { promises as fsp } from "fs";
import path from "path";
import os from "os";
import sharp from "sharp";
import { createWorker } from "tesseract.js"; // === engine utama
import { pipeline } from "@xenova/transformers"; // fallback semantic OCR (optional)

// ========================== Utils ==========================
function normalizeText(s = "") {
  return String(s)
    .replace(/\r/g, "\n")
    .replace(/[‐-‒–—―]+/g, "-")
    .replace(/[|¦]/g, " ")
    .replace(/[“”„‟]/g, '"')
    .replace(/[‘’‚‛]/g, "'")
    .replace(/\t/g, " ")
    .replace(/[ \u00A0]{2,}/g, " ")
    .trim();
}
function cleanup(s = "") {
  return String(s)
    .replace(/[|'"`~\\\/]+$/g, "")
    .replace(/^[|'"`~\\\/]+/g, "")
    .replace(/[ ]{2,}/g, " ")
    .trim();
}
function formatRupiahID(num) {
  if (num == null || Number.isNaN(num)) return "";
  try {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  } catch {
    return `Rp ${num}`;
  }
}
/** "43,500" | "43.500" | "Rp 1.234,00" -> 43500 */
function parseMoneyToNumber(s) {
  if (s == null) return null;
  let x = String(s)
    .replace(/[^\d.,-]/g, "")
    // hapus titik ribuan (titik yg diikuti 3 digit, bukan desimal)
    .replace(/\.(?=\d{3}(?:\D|$))/g, "")
    // koma sebagai desimal -> titik
    .replace(/,(\d{1,2})\b/g, ".$1")
    // sisa koma (ribuan) buang
    .replace(/,/g, "");
  const n = Number(x);
  return Number.isFinite(n) ? n : null;
}
function normalizeDateToken(t) {
  if (!t) return "";
  t = String(t).trim();
  let m = t.match(/\b(20\d{2})[-\/\.](\d{1,2})[-\/\.](\d{1,2})\b/);
  if (m) {
    const [_, y, mo, d] = m;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  m = t.match(/\b(\d{1,2})[-\/\.](\d{1,2})[-\/\.](20\d{2})\b/);
  if (m) {
    const [_, d, mo, y] = m;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  return t;
}

// ==================== Image pre-processing ====================
async function preprocessReceipt(inputPath) {
  const tmpDir = path.join(os.tmpdir(), "ocr-pre");
  await fsp.mkdir(tmpDir, { recursive: true }).catch(() => {});
  const out = path.join(
    tmpDir,
    `pre_${Date.now()}_${path.basename(inputPath).replace(/\s+/g, "_")}.png`
  );

  // Pipeline: auto-orient -> grayscale -> CLAHE -> unsharp -> adaptive threshold
  const img = sharp(inputPath).rotate().grayscale();

  // Sharpen ringan untuk teks kecil
  // (sigma kecil agar tidak bikin ringing)
  await img
    .linear(1.2, -10) // tingkatkan kontras global sedikit
    .sharpen(1) // asah tipis
    .median(1) // reduce noise bintik
    .toColourspace("b-w")
    .toBuffer({ resolveWithObject: true })
    .then(({ data, info }) =>
      sharp(data, { raw: info })
        .resize({ width: 1700, withoutEnlargement: true })
        .toFormat("png")
        .toFile(out)
    );

  return out.replace(/\\/g, "/");
}

// ====================== Tesseract Worker ======================
let _worker = null;
async function getTesseract() {
  if (_worker) return _worker;
  const worker = await createWorker("eng+ind", 1, {
    // cache langdata di user dir agar tidak download terus
    cacheMethod: "readOnly",
    errorHandler: () => {},
    logger: () => {}, // bisa diaktifkan untuk debug
  });
  // Mode bagus untuk struk (psm 6: Assume a single uniform block of text)
  await worker.setParameters({
    tessedit_pageseg_mode: "6",
    preserve_interword_spaces: "1",
    // filter karakter liar
    tessedit_char_blacklist: "~`_^{}[]<>§©®™¢£¥•●◆■▲▼✓✔★☆※¤¶",
  });
  _worker = worker;
  return worker;
}

// =================== Fallback Donut/TrOCR (opsional) ===================
let _donut = null;
async function getDonut() {
  if (_donut) return _donut;
  // model donat finetune CORD v2 (struk dokumen)
  _donut = await pipeline(
    "document-question-answering",
    "naver-clova-ix/donut-base-finetuned-cord-v2"
  );
  return _donut;
}

// =================== OCR Engines ===================
async function ocrWithTesseract(imagePath) {
  const pre = await preprocessReceipt(imagePath);
  const worker = await getTesseract();
  const { data } = await worker.recognize(pre);
  try {
    await fsp.unlink(pre);
  } catch {}
  return normalizeText(data.text);
}

async function ocrWithDonut(imagePath) {
  const pipe = await getDonut();
  // minta JSON “semantic” sederhana
  const prompt =
    "extract: store_name, date, items(name, qty, price), total, payment_method";
  const out = await pipe(imagePath, prompt);
  // Donut (Xenova) mengembalikan text; jaga-jaga jadikan string
  return normalizeText(typeof out === "string" ? out : out?.[0]?.answer || "");
}

// =================== Receipt Parser ===================
function parseReceipt(raw) {
  const text = normalizeText(raw);
  const lines = text
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);

  // 1) Nama toko: baris besar awal tanpa angka mencolok
  let store_name = "";
  for (const l of lines.slice(0, 6)) {
    if (/^(subtotal|total|payment|pembayaran|kembalian)/i.test(l)) break;
    if (/\d{3,}/.test(l)) continue;
    if (l.length >= 3) {
      store_name = cleanup(l.replace(/\b(struk|receipt|nota)\b/i, ""));
      if (store_name) break;
    }
  }

  // 2) Tanggal (coba ISO dulu, lalu pola “10 May 19”)
  let receipt_date = "";
  for (const l of lines) {
    const mIso =
      l.match(/\b(20\d{2})[-\/\.](\d{1,2})[-\/\.](\d{1,2})\b/) ||
      l.match(/\b(\d{1,2})[-\/\.](\d{1,2})[-\/\.](20\d{2})\b/);
    if (mIso) {
      receipt_date = normalizeDateToken(mIso[0]);
      break;
    }
    const mLong = l.match(
      /\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Mei|Okt|Des)\s+(\d{2,4})\b/i
    );
    if (mLong) {
      const dd = String(mLong[1]).padStart(2, "0");
      const mon = {
        jan: "01",
        feb: "02",
        mar: "03",
        apr: "04",
        may: "05",
        mei: "05",
        jun: "06",
        jul: "07",
        aug: "08",
        sep: "09",
        okt: "10",
        oct: "10",
        nov: "11",
        dec: "12",
        des: "12",
      }[mLong[2].toLowerCase()];
      const yyyy = mLong[3].length === 2 ? `20${mLong[3]}` : String(mLong[3]);
      receipt_date = `${yyyy}-${mon}-${dd}`;
      break;
    }
  }

  // 3) Items
  // Heuristik: baris yang berakhir dengan angka uang; optional “qty x price”
  const items = [];
  for (const l of lines) {
    if (
      /^(subtotal|total|jumlah|payment|pembayaran|kembalian|cash|debit|ppn|pajak)\b/i.test(
        l
      )
    )
      continue;

    const moneyEnd = l.match(/(\d[\d.,]*)\s*$/);
    if (!moneyEnd) continue;
    const endVal = parseMoneyToNumber(moneyEnd[1]);
    if (endVal == null) continue;

    let qty = 1;
    let unit = null;
    const mult = l.match(/(\d+)\s*[x×*]\s*(\d[\d.,]*)/i);
    if (mult) {
      qty = Number(mult[1]) || 1;
      unit = parseMoneyToNumber(mult[2]);
    }

    let name = l
      .replace(moneyEnd[1], "")
      .replace(mult?.[0] || "", "")
      .replace(/[.:]+$/g, "")
      .trim();
    name = cleanup(name) || "Item";

    const line_total = qty && unit != null ? qty * unit : endVal;

    items.push({
      name,
      qty: Number.isFinite(qty) && qty > 0 ? qty : 1,
      unit_price: unit,
      unit_price_formatted: unit != null ? formatRupiahID(unit) : "",
      line_total: line_total != null ? line_total : endVal,
      line_total_formatted:
        line_total != null
          ? formatRupiahID(line_total)
          : endVal != null
          ? formatRupiahID(endVal)
          : "",
    });
  }

  // 4) Total / Payment (prioritaskan “Total:” atau “Total”)
  let total_amount = null;
  for (const l of lines) {
    const m =
      l.match(/\b(grand\s*)?total\b[^\d]*([\d.,]+)/i) ||
      l.match(/\bpayment\b[^\d]*([\d.,]+)/i);
    if (m) {
      const n = parseMoneyToNumber(m[2] || m[1]);
      if (n != null) {
        total_amount = n;
        break;
      }
    }
  }
  // fallback jumlah dari item
  if (total_amount == null && items.length) {
    const sum = items.reduce((a, b) => a + (b.line_total || 0), 0);
    total_amount = Number.isFinite(sum) ? sum : null;
  }

  return {
    store_name: cleanup(store_name),
    total_amount,
    total_formatted: total_amount != null ? formatRupiahID(total_amount) : "",
    items,
    receipt_date,
    raw_text: text,
  };
}

// =================== Public API ===================
export async function extractWithLocalML(imagePath) {
  // 1) Coba Tesseract (paling stabil untuk struk Indo)
  let raw = "";
  try {
    raw = await ocrWithTesseract(imagePath);
  } catch (err) {
    // 2) Fallback Donut jika Tesseract gagal parah
    try {
      raw = await ocrWithDonut(imagePath);
    } catch (e2) {
      // 3) Fallback terakhir: baca biner apa adanya
      raw = "";
    }
  }

  // Simpan raw utk debugging
  try {
    const dbgDir = path.join(process.cwd(), "debug");
    await fsp.mkdir(dbgDir, { recursive: true });
    const fn = path.join(
      dbgDir,
      `raw_${Date.now()}_${path.basename(imagePath)}.txt`
    );
    await fsp.writeFile(fn, raw || "(empty)");
  } catch {}

  const obj = parseReceipt(raw);

  return {
    ...obj,
    model_used: "local:tesseract (eng+ind) → fallback donut-cord-v2",
  };
}

export async function extractFromTextLocal(freeText) {
  const obj = parseReceipt(normalizeText(freeText || ""));
  if ((!obj.items || obj.items.length === 0) && obj.total_amount != null) {
    const t = obj.total_amount;
    obj.items = [
      {
        name: "Belanja",
        qty: 1,
        unit_price: t,
        unit_price_formatted: formatRupiahID(t),
        line_total: t,
        line_total_formatted: formatRupiahID(t),
      },
    ];
  }
  return {
    ...obj,
    model_used: "local:text-parser",
  };
}
