import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import sqlite3 from "sqlite3";
import { open } from "sqlite";
import mime from "mime-types";
import { extractWithLocalML, extractFromTextLocal } from "./local_ml.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", CORS_ORIGIN);
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Content-Type, Authorization, X-Requested-With"
  );
  next();
});
app.options("*", (_req, res) => res.sendStatus(200));

const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const ext = mime.extension(file.mimetype) || "png";
    cb(null, `receipt_${Date.now()}.${ext}`);
  },
});
const upload = multer({
  storage,
  fileFilter: (_, file, cb) => {
    const ok = ["image/png", "image/jpeg", "image/webp", "image/jpg"];
    if (ok.includes(file.mimetype)) cb(null, true);
    else cb(new Error("Format gambar tidak didukung."));
  },
  limits: { fileSize: 10 * 1024 * 1024 },
});

let db;
(async () => {
  db = await open({
    filename: path.join(__dirname, "cv_data.db"),
    driver: sqlite3.Database,
  });
  await db.exec(`
    CREATE TABLE IF NOT EXISTS receipts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      store_name TEXT,
      total_amount REAL,
      total_formatted TEXT,
      items_json TEXT,
      receipt_date TEXT,
      image_path TEXT,
      raw_text TEXT,
      input_date TEXT,
      input_time TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
})();

function normalizeText(s) {
  return (s || "")
    .replace(/\r/g, "\n")
    .replace(/[‐-‒–—―]+/g, "-")
    .replace(/[|¦]/g, " ")
    .replace(/[“”„‟]/g, '"')
    .replace(/[‘’‚‛]/g, "'")
    .replace(/[\\/~]+/g, " ")
    .replace(/\t/g, " ")
    .replace(/[ ]{2,}/g, " ");
}
function cleanup(s = "") {
  return s
    .replace(/[|'"`~\\\/]+$/g, "")
    .replace(/^[|'"`~\\\/]+/g, "")
    .replace(/[ ]{2,}/g, " ")
    .trim();
}
function formatRupiahID(num) {
  if (num === null || num === undefined || Number.isNaN(num)) return "";
  try {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  } catch {
    return `Rp ${num}`;
  }
}
function normalizeDateToken(t) {
  if (!t) return "";
  t = String(t).trim();
  let m = t.match(/\b(20\d{2})[-\/](\d{1,2})[-\/](\d{1,2})\b/);
  if (m) {
    const [_, y, mo, d] = m;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  m = t.match(/\b(\d{1,2})[-\/](\d{1,2})[-\/](20\d{2})\b/);
  if (m) {
    const [_, d, mo, y] = m;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  return t;
}

const USE_GEMINI =
  String(process.env.USE_GEMINI || "false").toLowerCase() === "true";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const ENV_MODEL = process.env.GEMINI_MODEL || "";

const MODEL_CANDIDATES = [
  ENV_MODEL,
  "gemini-2.0-flash",
  "gemini-2.0-pro",
  "gemini-1.5-flash-latest",
  "gemini-1.5-flash",
  "gemini-1.5-pro-latest",
  "gemini-1.5-pro",
  "gemini-1.0-pro-vision-latest",
  "gemini-pro-vision",
].filter(Boolean);

const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1";

function buildGeminiRequest({ prompt, mimeType, base64 }) {
  return {
    contents: [
      {
        role: "user",
        parts: [
          { text: prompt },
          { inline_data: { mime_type: mimeType, data: base64 } },
        ],
      },
    ],
  };
}
function buildGeminiTextRequest({ systemPrompt, userText }) {
  return {
    contents: [
      { role: "user", parts: [{ text: systemPrompt }, { text: userText }] },
    ],
  };
}

async function callGeminiREST({ model, prompt, mimeType, base64 }) {
  const url = `${GEMINI_BASE}/models/${model}:generateContent?key=${encodeURIComponent(
    GEMINI_API_KEY
  )}`;
  const body = buildGeminiRequest({ prompt, mimeType, base64 });
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify(body),
  });
  const text = await r.text();
  if (!r.ok) {
    const err = new Error(
      `Gemini HTTP ${r.status} ${r.statusText} (${model}) -> ${text.slice(
        0,
        300
      )}`
    );
    err.status = r.status;
    err.payload = text;
    throw err;
  }
  const data = JSON.parse(text);
  const parts = data?.candidates?.[0]?.content?.parts || [];
  return parts
    .map((p) => p.text || "")
    .join("\n")
    .trim();
}

async function extractWithGemini(imagePath) {
  if (!(USE_GEMINI && GEMINI_API_KEY))
    throw new Error("Gemini dimatikan atau API key kosong.");
  const buf = fs.readFileSync(imagePath);
  const base64 = buf.toString("base64");
  const mimeType = mime.lookup(imagePath) || "image/png";

  const prompt = `
Kamu adalah extractor struk belanja. Baca gambar struk (Indonesia/Inggris),
kembalikan JSON VALID (tanpa teks lain) dengan skema:
{"store_name":string,"total_amount":number|null,"total_formatted":string,"receipt_date":string,"items":[{"name":string,"qty":number,"unit_price":number|null,"unit_price_formatted":string,"line_total":number|null,"line_total_formatted":string}],"raw_text":string}
Aturan: qty min 1; angka murni (tanpa "Rp"); *_formatted pakai format Rupiah; receipt_date format YYYY-MM-DD bila ada.`;

  let lastErr = null;
  for (const m of MODEL_CANDIDATES) {
    try {
      const rawOut = await callGeminiREST({
        model: m,
        prompt,
        mimeType,
        base64,
      });
      const cleaned = rawOut.replace(/```json|```/g, "").trim();
      const obj = JSON.parse(cleaned);

      const toNum = (v) =>
        v == null ? null : Number(String(v).replace(/[^\d.-]/g, ""));
      const total_amount = toNum(obj.total_amount);
      const items = Array.isArray(obj.items) ? obj.items : [];
      const normItems = items.map((it) => {
        let qty = Number(it?.qty);
        if (!qty || Number.isNaN(qty) || qty <= 0) qty = 1;
        const unit = toNum(it?.unit_price);
        const line =
          it?.line_total != null
            ? toNum(it.line_total)
            : unit != null
            ? unit * qty
            : null;
        return {
          name: cleanup(it?.name || "Item"),
          qty,
          unit_price: Number.isNaN(unit) ? null : unit,
          unit_price_formatted:
            unit != null && !Number.isNaN(unit) ? formatRupiahID(unit) : "",
          line_total: Number.isNaN(line) ? null : line,
          line_total_formatted:
            line != null && !Number.isNaN(line) ? formatRupiahID(line) : "",
        };
      });

      const recDate = obj.receipt_date
        ? normalizeDateToken(String(obj.receipt_date))
        : "";

      return {
        store_name: cleanup(obj.store_name || ""),
        total_amount: total_amount ?? null,
        total_formatted:
          total_amount != null && !Number.isNaN(total_amount)
            ? formatRupiahID(total_amount)
            : "",
        items: normItems,
        receipt_date: recDate,
        raw_text: normalizeText(obj.raw_text || ""),
        model_used: m,
      };
    } catch (err) {
      lastErr = err;
      if (err.status === 404) {
        console.warn(`[Gemini] ${m} → 404, fallback...`);
        continue;
      }
      console.warn(`[Gemini] ${m} → ${err.message}`);
      continue;
    }
  }
  throw new Error(
    `Semua kandidat model gagal. Terakhir: ${
      lastErr ? lastErr.message : "unknown error"
    }`
  );
}

async function extractFromTextGemini(freeText) {
  if (!(USE_GEMINI && GEMINI_API_KEY))
    throw new Error("Gemini dimatikan atau API key kosong.");

  const systemPrompt = `
Kamu mengekstrak transaksi belanja dari kalimat bebas (Indonesia).
Balas HANYA objek JSON dengan skema:
{"store_name":string,"total_amount":number|null,"total_formatted":string,"receipt_date":string,"items":[{"name":string,"qty":number,"unit_price":number|null,"unit_price_formatted":string,"line_total":number|null,"line_total_formatted":string}],"raw_text":string}
Aturan: jika tanggal tak ada → receipt_date=""; total_amount angka murni; *_formatted Rupiah.`;

  let lastErr = null;
  for (const m of MODEL_CANDIDATES) {
    try {
      const url = `${GEMINI_BASE}/models/${m}:generateContent?key=${encodeURIComponent(
        GEMINI_API_KEY
      )}`;
      const body = buildGeminiTextRequest({ systemPrompt, userText: freeText });
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json; charset=utf-8" },
        body: JSON.stringify(body),
      });
      const text = await r.text();
      if (!r.ok) {
        const err = new Error(
          `Gemini HTTP ${r.status} ${r.statusText} (${m}) -> ${text.slice(
            0,
            300
          )}`
        );
        err.status = r.status;
        throw err;
      }

      const data = JSON.parse(text);
      const rawOut = (data?.candidates?.[0]?.content?.parts || [])
        .map((p) => p.text || "")
        .join("\n")
        .trim();
      const cleaned = rawOut.replace(/```json|```/g, "").trim();
      const obj = JSON.parse(cleaned);

      const toNum = (v) =>
        v == null ? null : Number(String(v).replace(/[^\d.-]/g, ""));
      const total_amount = toNum(obj.total_amount);
      const items = Array.isArray(obj.items) ? obj.items : [];
      const normItems = items.map((it) => {
        let qty = Number(it?.qty);
        if (!qty || Number.isNaN(qty) || qty <= 0) qty = 1;
        const unit = toNum(it?.unit_price);
        const line =
          it?.line_total != null
            ? toNum(it.line_total)
            : unit != null
            ? unit * qty
            : total_amount ?? null;
        return {
          name: cleanup(it?.name || "Item"),
          qty,
          unit_price: Number.isNaN(unit) ? null : unit,
          unit_price_formatted:
            unit != null && !Number.isNaN(unit) ? formatRupiahID(unit) : "",
          line_total: Number.isNaN(line) ? null : line,
          line_total_formatted:
            line != null && !Number.isNaN(line) ? formatRupiahID(line) : "",
        };
      });

      const recDate = obj.receipt_date
        ? normalizeDateToken(String(obj.receipt_date))
        : "";

      return {
        store_name: cleanup(obj.store_name || ""),
        total_amount: total_amount ?? null,
        total_formatted:
          total_amount != null && !Number.isNaN(total_amount)
            ? formatRupiahID(total_amount)
            : "",
        items: normItems.length
          ? normItems
          : [
              {
                name: "Belanja",
                qty: 1,
                unit_price: total_amount,
                unit_price_formatted:
                  total_amount != null ? formatRupiahID(total_amount) : "",
                line_total: total_amount,
                line_total_formatted:
                  total_amount != null ? formatRupiahID(total_amount) : "",
              },
            ],
        receipt_date: recDate,
        raw_text: normalizeText(freeText),
        model_used: m,
      };
    } catch (err) {
      lastErr = err;
      if (err.status === 404) {
        console.warn(`[Gemini-text] ${m} → 404, fallback...`);
        continue;
      }
      console.warn(`[Gemini-text] ${m} → ${err.message}`);
      continue;
    }
  }
  throw new Error(
    `Semua kandidat model (text) gagal. Terakhir: ${
      lastErr ? lastErr.message : "unknown error"
    }`
  );
}

app.post("/api/ocr_receipt", upload.single("image"), async (req, res) => {
  try {
    if (!req.file)
      return res.status(400).json({ error: "File gambar wajib diunggah." });
    const imagePath = req.file.path;

    const engine = String(
      req.body?.engine || req.query?.engine || "gemini"
    ).toLowerCase();

    let extracted;
    if (engine === "local" || engine === "donut") {
      extracted = await extractWithLocalML(imagePath);
    } else {
      if (!(USE_GEMINI && GEMINI_API_KEY)) {
        return res.status(500).json({
          error:
            "USE_GEMINI=false atau GEMINI_API_KEY kosong. Set USE_GEMINI=true dan isi GEMINI_API_KEY.",
        });
      }
      extracted = await extractWithGemini(imagePath);
    }

    const now = new Date();
    const input_date = now.toISOString().slice(0, 10);
    const input_time = now.toTimeString().slice(0, 8);

    const stmt = await db.run(
      `INSERT INTO receipts (store_name, total_amount, total_formatted, items_json, receipt_date, image_path, raw_text, input_date, input_time)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [
        extracted.store_name || "",
        extracted.total_amount ?? null,
        extracted.total_formatted || "",
        JSON.stringify(extracted.items || []),
        extracted.receipt_date || "",
        imagePath,
        extracted.raw_text || "",
        input_date,
        input_time,
      ]
    );
    const id = stmt.lastID;

    const payload = {
      id,
      engine_selected: engine,
      ...extracted,
      image_path: imagePath,
      input_date,
      input_time,
    };

    if (process.env.N8N_WEBHOOK_URL) {
      fetch(process.env.N8N_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }).catch(() => {});
    }

    const engineDesc =
      engine === "local" || engine === "donut"
        ? `LOCAL ML: ${extracted.model_used}`
        : `Gemini: ${extracted.model_used}`;

    res.json({
      ok: true,
      id,
      message: `Ekstraksi sukses (${engineDesc}) & data disimpan.`,
      data: payload,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal memproses OCR.", detail: e.message });
  }
});

app.post("/api/ocr_manual", async (req, res) => {
  try {
    const text = (req.body?.text || "").trim();
    const engine = String(req.body?.engine || "gemini").toLowerCase();
    if (!text)
      return res.status(400).json({ error: "Teks transaksi wajib diisi." });

    let extracted;
    if (engine === "local" || engine === "donut") {
      extracted = await extractFromTextLocal(text);
    } else {
      if (!(USE_GEMINI && GEMINI_API_KEY)) {
        return res.status(500).json({
          error:
            "USE_GEMINI=false atau GEMINI_API_KEY kosong. Set USE_GEMINI=true dan isi GEMINI_API_KEY.",
        });
      }
      extracted = await extractFromTextGemini(text);
    }

    const now = new Date();
    const input_date = now.toISOString().slice(0, 10);
    const input_time = now.toTimeString().slice(0, 8);

    const stmt = await db.run(
      `INSERT INTO receipts (store_name, total_amount, total_formatted, items_json, receipt_date, image_path, raw_text, input_date, input_time)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [
        extracted.store_name || "",
        extracted.total_amount ?? null,
        extracted.total_formatted || "",
        JSON.stringify(extracted.items || []),
        extracted.receipt_date || "",
        null,
        extracted.raw_text || "",
        input_date,
        input_time,
      ]
    );
    const id = stmt.lastID;

    const payload = {
      id,
      engine_selected: engine,
      ...extracted,
      image_path: null,
      input_date,
      input_time,
    };

    if (process.env.N8N_WEBHOOK_URL) {
      fetch(process.env.N8N_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }).catch(() => {});
    }

    const engineDesc =
      engine === "local" || engine === "donut"
        ? `LOCAL ML: ${extracted.model_used}`
        : `Gemini: ${extracted.model_used}`;

    res.json({
      ok: true,
      id,
      message: `Input manual diproses (${engineDesc}) & disimpan.`,
      data: payload,
    });
  } catch (e) {
    console.error(e);
    res
      .status(500)
      .json({ error: "Gagal memproses input manual.", detail: e.message });
  }
});

app.get("/api/receipts", async (req, res) => {
  const { from, to, order = "desc", limit = "100" } = req.query || {};
  const isISO = (d) => typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d);

  const clauses = [];
  const params = [];

  if (from || to) {
    if (from && isISO(from)) {
      clauses.push("receipt_date >= ?");
      params.push(from);
    }
    if (to && isISO(to)) {
      clauses.push("receipt_date <= ?");
      params.push(to);
    }
    clauses.push("receipt_date IS NOT NULL AND receipt_date != ''");
  }

  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
  const lim = Math.max(1, Math.min(parseInt(limit, 10) || 100, 1000));
  const ord = String(order).toLowerCase() === "asc" ? "ASC" : "DESC";
  const orderBy = `
  ORDER BY
    CASE WHEN (receipt_date IS NULL OR receipt_date = '') THEN 1 ELSE 0 END,
    date(receipt_date) ${ord},
    id ${ord}
`;

  const rows = await db.all(
    `
    SELECT id, store_name, total_amount, total_formatted, items_json, receipt_date, image_path, raw_text, input_date, input_time, created_at
    FROM receipts
    ${where}
    ${orderBy}
    LIMIT ?
    `,
    [...params, lim]
  );

  const statRow = await db.get(
    `
    SELECT 
      COUNT(*) AS cnt,
      COALESCE(SUM(total_amount),0) AS total_amt
    FROM receipts
    ${where}
    `,
    params
  );

  const shaped = rows.map((r) => ({
    ...r,
    items: (() => {
      try {
        return JSON.parse(r.items_json || "[]");
      } catch {
        return [];
      }
    })(),
  }));

  const total_amount = Number(statRow?.total_amt || 0);
  res.json({
    rows: shaped,
    stats: {
      count: Number(statRow?.cnt || 0),
      total_amount,
      total_formatted: formatRupiahID(total_amount),
    },
  });
});

app.delete("/api/receipts/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!id) return res.status(400).json({ error: "ID tidak valid." });

    const row = await db.get(
      `SELECT image_path FROM receipts WHERE id = ?`,
      id
    );
    const result = await db.run(`DELETE FROM receipts WHERE id = ?`, id);
    if (result.changes === 0)
      return res.status(404).json({ error: "Data tidak ditemukan." });

    const img = row?.image_path;
    if (img && fs.existsSync(img)) {
      try {
        fs.unlinkSync(img);
      } catch {}
    }

    res.json({ ok: true, message: `Entri #${id} telah dihapus.` });
  } catch (e) {
    console.error(e);
    res
      .status(500)
      .json({ error: "Gagal menghapus entri.", detail: e.message });
  }
});

app.post("/api/admin/reset", async (req, res) => {
  try {
    const confirm = req.query.confirm || req.body?.confirm;
    if (confirm !== "RESET") {
      return res.status(400).json({
        error: "Tambahkan confirm=RESET untuk melanjutkan.",
      });
    }

    const dbPath = path.join(__dirname, "cv_data.db");
    const backupDir = path.join(__dirname, "backups");
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backupPath = path.join(backupDir, `cv_data_backup_${stamp}.db`);
    if (fs.existsSync(dbPath)) fs.copyFileSync(dbPath, backupPath);

    await db.exec("DELETE FROM receipts;");
    await db.exec("DELETE FROM sqlite_sequence WHERE name='receipts';");
    await db.exec("VACUUM;");

    const upDir = path.join(__dirname, "uploads");
    if (fs.existsSync(upDir)) {
      for (const f of fs.readdirSync(upDir)) {
        const p = path.join(upDir, f);
        try {
          fs.unlinkSync(p);
        } catch {}
      }
    }

    res.json({
      ok: true,
      message:
        "RESET selesai. Semua data & file upload dihapus. Salinan DB disimpan sebagai backup.",
      backup_path: backupPath,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal reset.", detail: e.message });
  }
});

app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Receipt OCR app running at http://localhost:${PORT}`);
  if (USE_GEMINI) {
    console.log(
      `Mode ekstraksi: GEMINI (REST v1). Model utama: ${ENV_MODEL || "auto"}`
    );
  } else {
    console.log(
      "Mode ekstraksi: NON-GEMINI (bisa pilih LOCAL ML/Donut dari UI)."
    );
  }
});
